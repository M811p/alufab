import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireRole, AuthError } from '@/lib/auth';

const UpdateSchema = z
  .object({
    role: z.enum(['ADMIN', 'MANAGER', 'ESTIMATOR', 'DESIGNER', 'PRODUCTION']).optional(),
    isActive: z.boolean().optional(),
  })
  .refine((d) => d.role !== undefined || d.isActive !== undefined, {
    message: 'يجب تحديد role أو isActive على الأقل',
  });

type RouteParams = { params: Promise<{ id: string }> };

/** يضمن بقاء مدير نظام نشط واحد على الأقل في المصنع */
async function wouldRemoveLastAdmin(tenantId: string, targetUserId: string): Promise<boolean> {
  const activeAdmins = await prisma.user.count({
    where: { tenantId, role: 'ADMIN', isActive: true, NOT: { id: targetUserId } },
  });
  return activeAdmins === 0;
}

/**
 * PATCH /api/team/:id — ADMIN فقط
 * تغيير دور عضو أو تفعيله/تعطيله.
 */
export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const actor = await requireRole('ADMIN');
    const { id } = await params;
    const body = UpdateSchema.parse(await req.json());

    const target = await prisma.user.findFirst({
      where: { id, tenantId: actor.tenantId },
      select: { id: true, role: true, isActive: true },
    });
    if (!target) {
      return NextResponse.json({ error: 'المستخدم غير موجود ضمن هذا المصنع' }, { status: 404 });
    }

    // حماية: لا يعدّل المدير صلاحياته أو حالته بنفسه (يمنع قفل النظام بالخطأ)
    if (target.id === actor.userId) {
      return NextResponse.json({ error: 'لا يمكنك تعديل دورك أو حالتك بنفسك — اطلب من مدير نظام آخر' }, { status: 409 });
    }

    // حماية: لا يُترك المصنع بدون مدير نظام نشط
    const demotingAdmin = target.role === 'ADMIN' && body.role !== undefined && body.role !== 'ADMIN';
    const deactivatingAdmin = target.role === 'ADMIN' && body.isActive === false;
    if ((demotingAdmin || deactivatingAdmin) && (await wouldRemoveLastAdmin(actor.tenantId, target.id))) {
      return NextResponse.json({ error: 'لا يمكن إزالة آخر مدير نظام نشط في المصنع' }, { status: 409 });
    }

    const updated = await prisma.user.update({
      where: { id: target.id },
      data: { ...(body.role && { role: body.role }), ...(body.isActive !== undefined && { isActive: body.isActive }) },
      select: { id: true, name: true, email: true, role: true, isActive: true },
    });

    return NextResponse.json(updated);
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.httpStatus });
    }
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: 'بيانات غير صالحة', details: err.flatten() }, { status: 400 });
    }
    console.error('[PATCH /api/team/:id]', err);
    return NextResponse.json({ error: 'خطأ داخلي في الخادم' }, { status: 500 });
  }
}

/**
 * DELETE /api/team/:id — ADMIN فقط
 * تعطيل العضو (Soft delete) بدل الحذف النهائي للحفاظ على سجل العمليات.
 */
export async function DELETE(_req: NextRequest, { params }: RouteParams) {
  try {
    const actor = await requireRole('ADMIN');
    const { id } = await params;

    const target = await prisma.user.findFirst({
      where: { id, tenantId: actor.tenantId },
      select: { id: true, role: true },
    });
    if (!target) {
      return NextResponse.json({ error: 'المستخدم غير موجود ضمن هذا المصنع' }, { status: 404 });
    }
    if (target.id === actor.userId) {
      return NextResponse.json({ error: 'لا يمكنك تعطيل حسابك بنفسك' }, { status: 409 });
    }
    if (target.role === 'ADMIN' && (await wouldRemoveLastAdmin(actor.tenantId, target.id))) {
      return NextResponse.json({ error: 'لا يمكن تعطيل آخر مدير نظام نشط في المصنع' }, { status: 409 });
    }

    await prisma.user.update({ where: { id: target.id }, data: { isActive: false } });
    return NextResponse.json({ message: 'تم تعطيل العضو — يمكن إعادة تفعيله لاحقاً' });
  } catch (err) {
    if (err instanceof AuthError) {
      return NextResponse.json({ error: err.message }, { status: err.httpStatus });
    }
    console.error('[DELETE /api/team/:id]', err);
    return NextResponse.json({ error: 'خطأ داخلي في الخادم' }, { status: 500 });
  }
}
